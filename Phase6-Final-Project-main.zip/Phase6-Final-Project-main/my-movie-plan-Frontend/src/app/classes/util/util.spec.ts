import { Util } from './util';

describe('Util', () => {
  it('should create an instance', () => {
    expect(new Util()).toBeTruthy();
  });
});
